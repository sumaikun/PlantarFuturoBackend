<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Responsability;
use Illuminate\Http\Request;

class ResponsabilityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Responsability  $responsability
     * @return \Illuminate\Http\Response
     */
    public function show(Responsability $responsability)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Responsability  $responsability
     * @return \Illuminate\Http\Response
     */
    public function edit(Responsability $responsability)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Responsability  $responsability
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Responsability $responsability)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Responsability  $responsability
     * @return \Illuminate\Http\Response
     */
    public function destroy(Responsability $responsability)
    {
        //
    }
}
