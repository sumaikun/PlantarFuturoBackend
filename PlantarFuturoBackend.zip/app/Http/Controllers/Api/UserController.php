<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
/**
* @OA\Info(title="Plantar Futuro API", version="1.0")
*
* @OA\Server(url="http://swagger.local")
*/
class UserController extends Controller
{
    
}
