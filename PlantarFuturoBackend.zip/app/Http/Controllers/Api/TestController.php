<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use \Illuminate\Support\Facades\Validator;
/**
* @OA\Server(url="http://localhost:8000")
*/

class TestController extends Controller
{

}
